﻿using BlazorApp.Models;
using BlazorApp.Services.Interfaces;

namespace BlazorApp.Services
{
    public class StudentService : IStudentService
    {
        private readonly IHttpService _httpService;
        private readonly string URL = "student";

        public StudentService(IHttpService httpService)
        {
            _httpService = httpService;
        }

        public async Task<List<Student>> GetAllAsync()
        {
            return await _httpService.Get<List<Student>>(URL);
        }

        public async Task<Student> AddAsync(Student student)
        {
            return await _httpService.Post<Student>(student, URL);
        }
    }
}
