﻿using BlazorApp.Services.Interfaces;
using System.Text;
using System.Text.Json;

namespace BlazorApp.Services
{
    public class HttpService : IHttpService
    {
        private readonly HttpClient _httpClient;
        private string _baseUrl;


        public HttpService(IHttpClientFactory httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient.CreateClient();
            _baseUrl = configuration["ApiSettings:BaseUrl"];
        }
        public async Task<T> Get<T>(string url)
        {
            try
            {

                var response = await _httpClient.GetAsync($"{_baseUrl}/{url}");

                if (response.IsSuccessStatusCode)
                {

                    string responseContent = await response.Content.ReadAsStringAsync();

                    return JsonSerializer.Deserialize<T>(responseContent);
                }
                else
                {
                    throw new Exception($"Error fetching data: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {

                throw new Exception("An error occurred while fetching data", ex);
            }

        }

        public async Task<T> Post<T>(T obj, string url)
        {
            try
            {
                var data = JsonSerializer.Serialize(obj);
                var content = new StringContent(data, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_baseUrl}/{url}", content);

                var responseBody = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {

                    string responseContent = await response.Content.ReadAsStringAsync();

                    return JsonSerializer.Deserialize<T>(responseContent);
                }
                else
                {
                    throw new Exception($"Error fetching data: {response.StatusCode}");
                }

            }
            catch (Exception)
            {

                throw;
            }
        }


    }
}
