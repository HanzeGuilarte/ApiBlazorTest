﻿using BlazorApp.Models;

namespace BlazorApp.Services.Interfaces
{
    public interface IStudentService
    {
        Task<List<Student>> GetAllAsync();
        Task<Student> AddAsync(Student student);
    }
}
