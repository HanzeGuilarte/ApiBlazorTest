﻿namespace BlazorApp.Services.Interfaces
{
    public interface IHttpService
    {
        Task<T> Get<T>(string url);
        Task<T> Post<T>(T obj, string url);
    }
}
