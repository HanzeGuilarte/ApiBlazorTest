﻿using BlazorApp.Services;
using BlazorApp.Services.Interfaces;

namespace BlazorApp
{
    public static class DependencyInyectionConfig
    {
        public static void AddDependencies(WebApplicationBuilder builder)
        {

            builder.Services.AddTransient<IHttpService, HttpService>();
            builder.Services.AddTransient<IStudentService, StudentService>();

        }
    }
}
