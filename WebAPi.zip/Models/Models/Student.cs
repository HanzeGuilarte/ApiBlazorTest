﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace BlazorApp.Models
{
    public class Student
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(30, ErrorMessage = "Name cannot be longer than 30 characters.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "First Name must contain only letters.")]
        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }


        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Last Name must contain only letters.")]
        [Required(ErrorMessage = "Last Name is required.")]
        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Age is required.")]
        [Range(18, 30, ErrorMessage = "Age must be between 18 and 30")]
        [JsonPropertyName("age")]
        public int Age { get; set; }

        [JsonPropertyName("major")]
        public string Major { get; set; }

        [EmailAddress(ErrorMessage = "Invalid email address.")]
        [JsonPropertyName("email")]
        public string Email { get; set; }

        public Student()
        {
            Age = 18;
            FirstName = "";
            LastName = "";
            Major = "";
            Email = "";
        }



    }
}
