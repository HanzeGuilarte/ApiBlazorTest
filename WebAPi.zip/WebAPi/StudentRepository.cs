﻿using BlazorApp.Models;

namespace WebAPi.Controllers
{
    public class StudentRepository : IStudentRepository
    {

        private Random random;
        private readonly List<Student> students;

        public StudentRepository()
        {

            random = new Random();
            students = new List<Student>
        {
            new Student
            {
                FirstName = "Alice",
                LastName = "Johnson",
                Age = 22,
                Major = "Computer Science",
                Email="alice@gmail.com"
            },
            new Student
            {
                FirstName = "Bob",
                LastName = "Smith",
                Age = 24,
                Major = "Mechanical Engineering",
                Email="bob@gmail.com"
            },
            new Student
            {
                FirstName = "Charlie",
                LastName = "Brown",
                Age = 20,
                Major = "Mathematics",
                Email="charli@gmail.com"
            }
        };

        }


        public async Task<Student> AddAsync(Student student)
        {

            Thread.Sleep(random.Next(0, 500));

            student.Id = Guid.NewGuid();
            students.Add(student);

            return student;
        }



        public async Task<IEnumerable<Student>> GetAllAsync()
        {

            Thread.Sleep(random.Next(0, 500));

            return students;


        }
    }
}
