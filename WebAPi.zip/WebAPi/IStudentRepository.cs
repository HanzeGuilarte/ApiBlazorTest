﻿using BlazorApp.Models;

namespace WebAPi
{
    public interface IStudentRepository
    {
        Task<Student> AddAsync(Student student);
        Task<IEnumerable<Student>> GetAllAsync();
    }
}
