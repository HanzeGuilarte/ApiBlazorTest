using BlazorApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebAPi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentController : ControllerBase
    {
        public IStudentRepository _studentRepository { get; set; }
        public StudentController(IStudentRepository studentRepository)
        {

            _studentRepository = studentRepository;
        }



        /* private readonly ILogger<WeatherForecastController> _logger;

         public WeatherForecastController(ILogger<WeatherForecastController> logger)
         {
             _logger = logger;
         }
 */
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetAllStudent()
        {
            try
            {
                return Ok(await _studentRepository.GetAllAsync());
            }
            catch (Exception ex)
            {

                return StatusCode(500, new { message = "Internal server error", details = ex.Message });
            }

        }


        [HttpPost]
        public async Task<ActionResult<IEnumerable<Student>>> AddStudent([FromBody] Student student)
        {
            try
            {
                return Ok(await _studentRepository.AddAsync(student));
            }
            catch (Exception ex)
            {

                return StatusCode(500, new { message = "Internal server error", details = ex.Message });
            }


        }
    }
}
